create definer = root@localhost view v_payments as
select `p`.`payment_id`  AS `payment_id`,
       `a`.`account_id`  AS `account_id`,
       `u`.`user_id`     AS `user_id`,
       `p`.`beneficiary` AS `beneficiary`,
       `p`.`iban`        AS `iban`,
       `p`.`amount`      AS `amount`,
       `p`.`status`      AS `status`,
       `p`.`reason_code` AS `reason_code`,
       `p`.`created_at`  AS `created_at`
from ((`e_banking_app_licenta`.`payments` `p` join `e_banking_app_licenta`.`accounts` `a`
       on ((`p`.`account_id` = `a`.`account_id`))) join `e_banking_app_licenta`.`users` `u`
      on ((`a`.`user_id` = `u`.`user_id`)));

