create definer = root@localhost view v_transaction_history as
select `t`.`transaction_id`   AS `transaction_id`,
       `a`.`account_id`       AS `account_id`,
       `u`.`user_id`          AS `user_id`,
       `t`.`transaction_type` AS `transaction_type`,
       `t`.`amount`           AS `amount`,
       `t`.`source`           AS `source`,
       `t`.`status`           AS `status`,
       `t`.`reason_code`      AS `reason_code`,
       `t`.`created_at`       AS `created_at`
from ((`e_banking_app_licenta`.`transaction_history` `t` join `e_banking_app_licenta`.`accounts` `a`
       on ((`t`.`account_id` = `a`.`account_id`))) join `e_banking_app_licenta`.`users` `u`
      on ((`a`.`user_id` = `u`.`user_id`)));

